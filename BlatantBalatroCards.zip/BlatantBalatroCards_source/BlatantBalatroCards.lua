--- STEAMODDED HEADER
--- MOD_NAME: Blatant Balatro Cards
--- MOD_ID: BlatantBalatroCards
--- MOD_AUTHOR: [morrysillusion]
--- MOD_DESCRIPTION: Makes players cards clear with text for each suit and number

----------------------------------------------
------------MOD CODE -------------------------

function SMODS.INIT.DecColors()

    local dec_mod = SMODS.findModByID("BlatantBalatroCards")
    local sprite_card = SMODS.Sprite:new("cards_1", dec_mod.path, "BlatantCards.png", 71, 95, "asset_atli")
    
    sprite_card:register()
end

----------------------------------------------
------------MOD CODE END----------------------
